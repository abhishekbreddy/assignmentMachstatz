import React, { Component } from 'react'
import Axios from 'axios'
import {context} from './Context'
import {apiData} from './Context'


 class Planet extends Component {
     constructor(props) {
         super(props)
     
         this.state = {
              data:[]
         }
     }
     fn(e,data1) {
    e.target.setAttribute("disabled",true)
 let filterData = apiData.data.filter((data)=>{
                     return data.id === data1.id
  })
  
   
   filterData[0].isFavourite = true
   console.log(filterData[0])
  apiData.filteredData.push(filterData[0])
   console.log(apiData.filteredData)
   console.log(context)
 
  
     }
     componentDidMount() {
         alert("ok")
          Axios.get("https://assignment-machstatz.herokuapp.com/planet").then((res)=>{
                 this.setState({
                     data:res.data
                 })
                 apiData.data =res.data
               console.log("apidata",apiData.data)
          },(err)=>{
            alert(err)
          })
     }
     
    render() {
        return (
            <div className="container m-3">
                <div className="col-md-12">
                <table className="table table-hover">
                    <tr className="bg-dark text-white">
                        <th>Planets</th>
                        <th>Select To Make Favourite</th>
                    </tr>
             {
                 this.state.data.length > 1 ? this.state.data.map((data)=>{
                       return (
                           <>
                             <tr>
                              <td className="list-group-item">{data.name}</td>
                            <td>  <input type="radio"  onChange={(e)=>{ this.fn(e,data)}} /></td></tr>
                           </>
                       )
                 }) :<h1>NO Data</h1>
             }
             </table>
         </div>
            </div>
        )
    }
}
export default Planet