import React,{useContext} from 'react'
import {context} from './Context'

function Fav() {
    let contextData = useContext(context)
    console.log(contextData)
  return (
    <div className="container">
        <div className="row">
           

         
   {
       contextData.filteredData.map((data)=>{
           return(
               <>
                <div className="col-md-4">
                <div className="card mt-2">
                    <div className="card-header bg-dark text-white">
                        Favourites
                    </div>
                    <div className="card-body">
                     NAME: {data.name}
                    </div>
                </div>
                </div>
               </>
           )
       })
   }
     
        </div>
    </div>
  )
}

export default Fav
