import React, { Component } from 'react'
import {Link} from 'react-router-dom'

export default class Nav extends Component {
    render() {
        return (
            <div>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <Link class="navbar-brand" href="#">React</Link>
  
 
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <Link class="nav-link active"  to="/">Home</Link>
        </li>
        <li class="nav-item">
          <Link class="nav-link" to="/fav">Favourites</Link>
        </li>
       
        
      </ul>
    </div>
  </div>
</nav>
            </div>
        )
    }
}
