import React from 'react'

export let apiData = {
    data:[],
    filteredData:[]
}
export let context = React.createContext()

