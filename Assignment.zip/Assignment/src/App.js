import React from 'react';
// import A from './A'
import './App.css';
// import Navbar from './components/navbar/index'
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import Planet from './components/Planet'
import Fav from './components/Fav'
import {BrowserRouter as Router,Switch,Route} from 'react-router-dom'
import Nav from './components/Nav'

function App() {
  return (
    <div className="App">
      <Router>
       <Nav />
        <Switch>
          <Route exact path="/" component={Planet} />
          <Route exact path="/fav" component={Fav} />
        </Switch>
      </Router>
   
    {/* <Fav /> */}

    </div>
  );
  
}

export default App;
